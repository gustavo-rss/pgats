const calcularTotal = (ferramentas, comprar) => {
    let valorTotal = 0;
    
    if (comprar.length === 0) {
        throw new Error("Ambas as listas precisam ter ao menos um item.");
    }

    if (ferramentas.length === 0) {
        throw new Error("Ambas as listas precisam ter ao menos um item.");
    }

    comprar.forEach(itemCompra => {
        const ferramenta = ferramentas.find(ferramenta => ferramenta.nome === itemCompra);
        if (ferramenta) {
            valorTotal += ferramenta.preco;
        }
    });

    if (valorTotal === 0) {
        throw new Error("Nenhuma ferramenta desejada encontrada.");
    }

    valorTotal = valorTotal.toFixed(2);
    return (`O valor a pagar pelas ferramentas (${comprar.join(', ')}) é R$ ${valorTotal}`);
}

module.exports = {
    calcularTotal
}